pip3 install sklearn
pip3 install pandas
pip3 install numpy