# Copyright (c) 2020 Cloudera, Inc. All rights reserved.

import sys
import cdsw
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score
from sklearn import preprocessing
import pickle

# == For Testing ==
features = ['bedrooms', 'bathrooms', 'sqft_living',
       'sqft_lot', 'floors', 'waterfront', 'condition']
args = {
  "bathrooms": "2",
  "bedrooms": "3",
  "sqft_living": "1800",
  "sqft_lot": "2200",
  "floors": "1",
  "waterfront": "1",
  "condition": "3"
}


# == Main Function ==
def PredictFunc(args):
	# Load Data
	filtArgs = {key: [args[key]] for key in features}
	data = pd.DataFrame.from_dict(filtArgs)

	# Load Model
	with open('housePredictor.pickle', 'rb') as handle:
		mdl = pickle.load(handle)
	model = pickle.loads(mdl)

	# Get Prediction
	prediction = model.predict(data)

	# Return Prediction
	return prediction