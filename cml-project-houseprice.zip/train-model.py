# Copyright (c) 2020 Cloudera, Inc. All rights reserved.

import sys
import cdsw
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score
from sklearn import preprocessing
import pickle

# decode input(s)
folds = 3

# read from CSVs
df = pd.read_csv('house_data.csv', sep=',',header=0)

# extract data
features = df[['bedrooms', 'bathrooms', 'sqft_living',
       'sqft_lot', 'floors', 'waterfront', 'condition']]
prices = df[['price']]

# Setup Model
regModel = LinearRegression()
regModel.fit(features,prices)

# Validate Model
scores = cross_val_score(regModel, features, prices, cv=folds)
avgAcc = np.mean(scores)
print(avgAcc)

# Save Model
mdl = pickle.dumps(regModel)
with open('housePredictor.pickle', 'wb') as handle:
	pickle.dump(mdl, handle)
